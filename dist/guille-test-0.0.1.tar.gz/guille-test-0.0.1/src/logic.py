def do_something():
    print("hola")
