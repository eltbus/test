from src.logic import do_something

if __name__ == '__main__':
    do_something()
